package com.mercadolibre.mutantdetector.controller;

import com.mercadolibre.mutantdetector.dto.DnaRequest;
import com.mercadolibre.mutantdetector.dto.StatsResponse;
import com.mercadolibre.mutantdetector.service.MutantService;
import com.mercadolibre.mutantdetector.service.StatsService;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
@RequestMapping("/api")
@Tag(name = "Mutantes", description = "Operaciones para detección y estadísticas de mutantes")
public class MutantController {

    private final MutantService mutantService;
    private final StatsService statsService;

    public MutantController(MutantService mutantService, StatsService statsService) {
        this.mutantService = mutantService;
        this.statsService = statsService;
    }

    // ==============================
    //          POST /mutant
    // ==============================
    @PostMapping("/mutant")
    @Operation(
            summary = "Detecta si un ADN pertenece a un mutante",
            description = "Devuelve 200 OK si el ADN es mutante, 403 Forbidden si es humano.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Mutante detectado"),
                    @ApiResponse(responseCode = "403", description = "ADN humano"),
                    @ApiResponse(responseCode = "400", description = "ADN inválido (estructura o caracteres)")
            }
    )
    public ResponseEntity<?> analizarADN(@Valid @RequestBody DnaRequest dto) {

        boolean esMutante = mutantService.analizarYGuardar(dto.getDna().toArray(new String[0]));

        if (esMutante) {
            // BODY opcional, pero devuelvo JSON vacío para cumplir forma:
            return ResponseEntity.ok(new StatsResponse(true));
        } else {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(new StatsResponse(false));
        }
    }

    // ==============================
    //       GET /estadisticas
    // ==============================
    @GetMapping("/estadisticas")
    @Operation(
            summary = "Devuelve estadísticas de ADN evaluado",
            description = "Cantidad de mutantes, humanos y ratio entre ellos.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Estadísticas generadas correctamente")
            }
    )
    public ResponseEntity<?> obtenerEstadisticas() {

        long mutantes = statsService.countMutantes();
        long humanos = statsService.countHumanos();
        double ratio = statsService.ratio();

        return ResponseEntity.ok(
                new StatsResponse (mutantes, humanos, ratio)
        );
    }
}
