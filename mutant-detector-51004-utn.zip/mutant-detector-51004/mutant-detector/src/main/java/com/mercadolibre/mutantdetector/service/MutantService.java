package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.entity.DnaRecord;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class MutantService {

    private final MutantDetector detector;
    private final DnaRecordRepository repo;

    public MutantService(MutantDetector detector, DnaRecordRepository repo) {
        this.detector = detector;
        this.repo = repo;
    }

    @Transactional
    public boolean analizarYGuardar(String[] dna) {

        String hash = DigestUtils.sha256Hex(String.join("|", dna));

        Optional<DnaRecord> existente = repo.findByDnaHash(hash);
        if (existente.isPresent()) {
            return existente.get().isEsMutante();
        }

        boolean esMutante = detector.esMutante(dna);

        DnaRecord m = new DnaRecord();
        m.setEsMutante(esMutante);
        m.setDna(String.join(",", dna));
        m.setDnaHash(hash);
        m.setCreatedAt(LocalDateTime.now());

        repo.save(m);

        return esMutante;
    }
}
