package com.mercadolibre.mutantdetector.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

@Data
@AllArgsConstructor
@Schema(description = "DTO de estadísticas de ADN analizado")
public class StatsResponse {

    private long countMutantDna;
    private long countHumanDna;
    private double ratio;

    public StatsResponse(boolean b) {
    }
}
