package com.mercadolibre.mutantdetector.dto;

import lombok.Data;
import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.validation.constraints.*;
import java.util.List;

@Data
@Schema(description = "DTO de entrada para analizar ADN mutante")
public class DnaRequest {

    @NotNull(message = "El campo dna no puede ser null")
    @NotEmpty(message = "El campo dna no puede estar vacío")
    private List<
            @Pattern(
                    regexp = "^[ACGT]+$",
                    message = "Cada fila debe contener solo caracteres A, C, G o T"
            )
                    String> dna;
}
