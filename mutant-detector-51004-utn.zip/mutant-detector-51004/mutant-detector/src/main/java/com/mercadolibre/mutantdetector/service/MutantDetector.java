package com.mercadolibre.mutantdetector.service;

import org.springframework.stereotype.Component;
import java.util.Set;

@Component
public class MutantDetector {

    private static final int SEQUENCE_LENGTH = 4;
    private static final Set<Character> VALID_BASES = Set.of('A', 'T', 'C', 'G');

    // Método que los tests y tu aplicación realmente usan
    public boolean esMutante(String[] dna) {
        return isMutant(dna);
    }

    // Lógica principal del detector
    public boolean isMutant(String[] dna) {
        validateInput(dna);

        int n = dna.length;
        char[][] matrix = convertToMatrix(dna);
        int count = 0;

        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {

                if (count > 1) return true;

                // → Horizontal
                if (col <= n - SEQUENCE_LENGTH &&
                        checkSequence(matrix, row, col, 0, 1)) {
                    count++;
                }

                // ↓ Vertical
                if (row <= n - SEQUENCE_LENGTH &&
                        checkSequence(matrix, row, col, 1, 0)) {
                    count++;
                }

                // ↘ Diagonal principal
                if (row <= n - SEQUENCE_LENGTH &&
                        col <= n - SEQUENCE_LENGTH &&
                        checkSequence(matrix, row, col, 1, 1)) {
                    count++;
                }

                // ↙ Diagonal secundaria
                if (row <= n - SEQUENCE_LENGTH &&
                        col >= SEQUENCE_LENGTH - 1 &&
                        checkSequence(matrix, row, col, 1, -1)) {
                    count++;
                }
            }
        }

        return count >= 1;

    }

    private boolean checkSequence(char[][] matrix, int row, int col, int rowStep, int colStep) {
        char base = matrix[row][col];

        for (int k = 1; k < SEQUENCE_LENGTH; k++) {
            int r = row + rowStep * k;
            int c = col + colStep * k;

            if (matrix[r][c] != base) return false;
        }
        return true;
    }

    private void validateInput(String[] dna) {
        if (dna == null || dna.length < SEQUENCE_LENGTH) {
            throw new IllegalArgumentException("DNA must be at least NxN with size >= 4");
        }

        int n = dna.length;

        for (int i = 0; i < n; i++) {
            String row = dna[i];

            if (row == null || row.length() != n) {
                throw new IllegalArgumentException("DNA matrix must be NxN");
            }

            for (int j = 0; j < n; j++) {
                char base = Character.toUpperCase(row.charAt(j));
                if (!VALID_BASES.contains(base)) {
                    throw new IllegalArgumentException("Invalid character '" + base + "' at [" + i + "][" + j + "]");
                }
            }
        }
    }

    private char[][] convertToMatrix(String[] dna) {
        int n = dna.length;
        char[][] m = new char[n][n];

        for (int i = 0; i < n; i++) {
            m[i] = dna[i].toUpperCase().toCharArray();
        }

        return m;
    }
}
