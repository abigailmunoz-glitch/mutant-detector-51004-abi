package com.mercadolibre.mutantdetector.repository;

import com.mercadolibre.mutantdetector.entity.DnaRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface DnaRecordRepository extends JpaRepository<DnaRecord, Long> {

    long countByEsMutante(boolean esMutante);

    Optional<DnaRecord> findByDnaHash(String dnaHash);
}
