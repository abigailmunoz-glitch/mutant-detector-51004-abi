package com.mercadolibre.mutantdetector.service;

import org.springframework.stereotype.Service;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;

@Service
public class StatsService {

    private final DnaRecordRepository repo;

    public StatsService(DnaRecordRepository repo) {
        this.repo = repo;
    }

    public long countMutantes() {
        return repo.countByEsMutante(true);
    }

    public long countHumanos() {
        return repo.countByEsMutante(false);
    }

    public double ratio() {
        long mutantes = countMutantes();
        long humanos = countHumanos();

        return humanos == 0 ? 0 : (double) mutantes / humanos;
    }
}

