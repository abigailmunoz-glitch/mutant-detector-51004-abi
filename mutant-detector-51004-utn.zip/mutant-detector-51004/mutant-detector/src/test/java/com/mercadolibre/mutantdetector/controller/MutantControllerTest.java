package com.mercadolibre.mutantdetector.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mercadolibre.mutantdetector.dto.DnaRequest;
import com.mercadolibre.mutantdetector.service.MutantService;
import com.mercadolibre.mutantdetector.service.StatsService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(MutantController.class)
class MutantControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private MutantService mutantService;

    @MockBean
    private StatsService statsService;

    @Autowired
    private ObjectMapper mapper;

    @Test
    void debeRetornar200SiEsMutante() throws Exception {

        when(mutantService.analizarYGuardar(any(String[].class)))
                .thenReturn(true);

        DnaRequest dto = new DnaRequest();
        dto.setDna(List.of("ATGC", "CAGT", "TTAT", "AGAA"));

        mockMvc.perform(
                post("/api/mutant")
                        .contentType(APPLICATION_JSON)
                        .content(mapper.writeValueAsString(dto))
        ).andExpect(status().isOk());
    }

    @Test
    void debeRetornar403SiEsHumano() throws Exception {

        when(mutantService.analizarYGuardar(any(String[].class)))
                .thenReturn(false);

        DnaRequest dto = new DnaRequest();
        dto.setDna(List.of("ATGC", "CAGT", "TTAT", "AGAC"));

        mockMvc.perform(
                post("/api/mutant")
                        .contentType(APPLICATION_JSON)
                        .content(mapper.writeValueAsString(dto))
        ).andExpect(status().isForbidden());
    }

    @Test
    void debeRetornar200Stats() throws Exception {

        when(statsService.countMutantes()).thenReturn(40L);
        when(statsService.countHumanos()).thenReturn(100L);
        when(statsService.ratio()).thenReturn(0.4);

        mockMvc.perform(
                get("/api/estadisticas")
        ).andExpect(status().isOk());
    }
}
