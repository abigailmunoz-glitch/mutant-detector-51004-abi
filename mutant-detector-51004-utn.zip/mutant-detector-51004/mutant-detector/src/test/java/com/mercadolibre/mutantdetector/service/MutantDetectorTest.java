package com.mercadolibre.mutantdetector.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MutantDetectorTest {

    private MutantDetector detector;

    @BeforeEach
    void setUp() {
        detector = new MutantDetector();
    }

    @Test
    void debeDetectarMutanteHorizontal() {
        String[] dna = {
                "AAAA",
                "CAGT",
                "TTAT",
                "AGAC"
        };
        assertTrue(detector.esMutante(dna));
    }

    @Test
    void debeDetectarMutanteVertical() {
        String[] dna = {
                "ATGC",
                "ATGT",
                "ATAT",
                "ATAC"
        };
        assertTrue(detector.esMutante(dna));
    }

    @Test
    void debeDetectarMutanteDiagonal() {
        String[] dna = {
                "ATGC",
                "CAGT",
                "TTAT",
                "AGAA"
        };
        assertTrue(detector.esMutante(dna));
    }

    @Test
    void noEsMutante() {
        String[] dna = {
                "ATGC",
                "CAGT",
                "TTAT",
                "AGAC"
        };
        assertFalse(detector.esMutante(dna));
    }

    @Test
    void debeLanzarExcepcionPorCaracterInvalido() {
        String[] dna = {
                "AXGC",
                "CAGT",
                "TTAT",
                "AGAC"
        };
        assertThrows(IllegalArgumentException.class, () -> detector.esMutante(dna));
    }

    @Test
    void debeLanzarExcepcionPorMatrizNoCuadrada() {
        String[] dna = {
                "ATG",
                "CAGT",
                "TTAT"
        };
        assertThrows(IllegalArgumentException.class, () -> detector.esMutante(dna));
    }
}
