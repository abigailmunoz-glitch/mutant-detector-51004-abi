package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.entity.DnaRecord;
import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MutantServiceTest {

    private DnaRecordRepository repo;
    private MutantDetector detector;
    private MutantService service;

    @BeforeEach
    void setUp() {
        repo = mock(DnaRecordRepository.class);
        detector = mock(MutantDetector.class);
        service = new MutantService(detector, repo);
    }

    @Test
    void siExisteHashDebeRetornarValorExistente() {
        String[] dna = {"AAAA", "CCCC", "TTTT", "GGGG"};

        DnaRecord existente = new DnaRecord();
        existente.setEsMutante(true);

        when(repo.findByDnaHash(anyString())).thenReturn(Optional.of(existente));

        boolean result = service.analizarYGuardar(dna);

        assertTrue(result);
        verify(detector, times(0)).esMutante(any());
    }

    @Test
    void siEsNuevoDebeSerGuardado() {
        String[] dna = {"ATGC", "CAGT", "TTAT", "AGGC"};

        when(repo.findByDnaHash(anyString())).thenReturn(Optional.empty());
        when(detector.esMutante(dna)).thenReturn(true);

        boolean result = service.analizarYGuardar(dna);

        assertTrue(result);
        verify(repo, times(1)).save(any(DnaRecord.class));
    }
}
