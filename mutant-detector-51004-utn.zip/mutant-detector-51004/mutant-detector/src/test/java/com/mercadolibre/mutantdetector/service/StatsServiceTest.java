package com.mercadolibre.mutantdetector.service;

import com.mercadolibre.mutantdetector.repository.DnaRecordRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class StatsServiceTest {

    private DnaRecordRepository repo;
    private StatsService service;

    @BeforeEach
    void setUp() {
        repo = mock(DnaRecordRepository.class);
        service = new StatsService(repo);
    }

    @Test
    void testRatioCorrecto() {
        when(repo.countByEsMutante(true)).thenReturn(40L);
        when(repo.countByEsMutante(false)).thenReturn(100L);

        assertEquals(0.4, service.ratio());
    }

    @Test
    void testRatioDividePorCeroDa0() {
        when(repo.countByEsMutante(true)).thenReturn(10L);
        when(repo.countByEsMutante(false)).thenReturn(0L);

        assertEquals(0, service.ratio());
    }
}
